## Example Usage

See the Jupyter notebook in `docs/example_usage.ipynb` for step-by-step substitution and scoring.