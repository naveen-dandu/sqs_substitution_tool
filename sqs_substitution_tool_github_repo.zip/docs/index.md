# SQS Substitution Tool

This site documents the SQS-style substitution tool for generating VASP-compatible POSCAR structures.