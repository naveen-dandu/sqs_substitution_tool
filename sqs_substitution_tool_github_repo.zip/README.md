# sqs_substitution_tool

A substitution-based randomizer for generating VASP-compatible POSCAR files.